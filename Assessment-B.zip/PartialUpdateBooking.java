package basics;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class PartialUpdateBooking {

	
	@Test
	public void CreateChangeReq() {
		
//		Step 1: Get the Endpoint / URL for the services
//		RestAssured.baseURI = "https://restful-booker.herokuapp.com/apidoc/index.html#api-Booking-PartialUpdateBooking";
		String jsonString = "{\r\n" + 
				"    \"firstname\" : \"James\",\r\n" + 
				"    \"lastname\" : \"Brown\"}";
//		Step 2: Patch
		
		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.JSON);
		request.cookie("token", "abc123");
		request.baseUri("https://restful-booker.herokuapp.com/apidoc/index.html#api-Booking-PartialUpdateBooking");
		request.body(jsonString);

		Response response = request.patch();
		System.out.println(response.asString());
		System.out.println("Response Status Code: " + response.statusCode());
		if (response.statusCode()==201)
	    {
	       System.out.println("Partial Update Booking - Success");
	    }
	    else
	    {
	       System.out.println("Partial Update Booking - Fail");
	    }
		ValidatableResponse validatableResponse = response.then();
		validatableResponse.statusCode(200);
		
		validatableResponse.body("firstname", Matchers.equalTo("James"));
	}
}
