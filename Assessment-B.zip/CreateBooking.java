

package basics;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

public class CreateBooking {

	
	@Test
	public void CreateChangeReq() {
		
//		Step 1: Get the Endpoint / URL for the services
		RestAssured.baseURI = "https://restful-booker.herokuapp.com/apidoc/index.html#api-Booking-CreateBooking";
		
//		Step 2: Post
		Response resp = RestAssured
				.given()
				.contentType(ContentType.JSON)
				.body("  {\"firstname\" : \"Jim\",\"lastname\" : \"Brown\",\"totalprice\" : \"111\",\"additionalneeds\" : \"Breakfast\"}")
				.post();
//        resp.prettyPrint();
        
        JsonPath jsonPath = resp.jsonPath();
//		Step 3: Checking Status Code
        System.out.println("Response Status Code: " + resp.statusCode());
        
       if (resp.statusCode()==201)
       {
    	   System.out.println("Create Booking - Success");
       }
       else
       {
    	   System.out.println("Create Booking - Fail");
       }
       ValidatableResponse validatableResponse = resp.then();
	   validatableResponse.statusCode(201);
	}
}
